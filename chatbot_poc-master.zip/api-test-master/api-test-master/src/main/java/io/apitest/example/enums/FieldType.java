package io.apitest.example.enums;

/**
 * Created by prasantabiswas on 26/06/18.
 */
public enum FieldType {

    STRING,
    DATETIME,
    INTEGER,
    FLOAT,
    DOUBLE,
    DECIMAL,
    BOOLEAN
}
