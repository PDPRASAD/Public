package main.java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class ChatbotPanel extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel jp;
	JTextField jt;
	JTextArea ta;
	JLabel l;
	boolean typing;
	Timer t;
	// JTextPane textPane;

	CustomTextPane textPane = new CustomTextPane();

	public ChatbotPanel() throws BadLocationException {
		createAndShowGUI();
	}

	private void createAndShowGUI() throws BadLocationException {

		// Set frame properties
		setTitle("Dell Autobot");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// Create a JPanel and set layout
		jp = new JPanel();
		jp.setLayout(new GridLayout(2, 1));
		l = new JLabel();
		jp.add(l);

		// Create a timer that executes every 1 millisecond
		t = new Timer(1, new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				// If the user isn't typing, he is thinking
				if (!typing)
					l.setText("Dell Autobot Thinking..");
			}
		});

		// Set initial delay of 2000 ms
		// That means, actionPerformed() is executed 2500ms
		// after the start() is called
		t.setInitialDelay(2000);

		// Create JTextField, add it.
		jt = new JTextField();
		jp.add(jt);

		// Add panel to the south,
		add(jp, BorderLayout.SOUTH);

		// Add a KeyListener
		jt.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent ke) {

				// Key pressed means, the user is typing
				l.setText("You are typing..");

				// When key is pressed, stop the timer
				// so that the user is not thinking, he is typing
				t.stop();

				// He is typing, the key is pressed
				typing = true;

				// If he presses enter, add text to chat textarea
				if (ke.getKeyCode() == KeyEvent.VK_ENTER) {
					String getTxt = jt.getText();
					try {
						UpdateInfoPanel(textPane, "You:" + getTxt);
						Chatbot cht = new Chatbot();
						String resp = cht.getTextMessage(getTxt);
						UpdateInfoPanel(textPane, "Technical Assistant:" + resp);
					} catch (BadLocationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				// Chatbot cht=new Chatbot();
				// String resp=cht.getTextMessage(jt.getText());
				// showLabel("Technical Assistant:"+resp);
			}

			public void keyReleased(KeyEvent ke) {

				// When the user isn't typing..
				typing = false;

				// If the timer is not running, i.e.
				// when the user is not thinking..
				if (!t.isRunning())

					// He released a key, start the timer,
					// the timer is started after 2500ms, it sees
					// whether the user is still in the keyReleased state
					// which means, he is thinking
					t.start();
			}
		});

		// Create a textarea
		/*
		 * ta=new JTextArea();
		 * 
		 * // Make it non-editable ta.setEditable(false);
		 * 
		 * // Set some margin, for the text ta.setMargin(new Insets(7,7,7,7));
		 */

		// textPane = new JTextPane();

		/*
		 * StyledDocument doc = (StyledDocument) textPane.getDocument();
		 * 
		 * Style style = doc.addStyle("StyleName", null);
		 * StyleConstants.setIcon(style, new
		 * ImageIcon("src/main/img/dell-logo.png"));
		 * 
		 * doc.insertString(doc.getLength(), "ignored text", style);
		 */
		// textPane.setBackground(Color.BLUE);
		textPane.setFont(new Font("Dialog", Font.PLAIN, 16));
		textPane.setEditable(false);
		textPane.setMargin(null);

		// textPane.setContentType("text/html");

		// Set a scrollpane
		JScrollPane js = new JScrollPane(textPane);
		add(js);

		setBackground(Color.DARK_GRAY);
		textPane.setBorder(null);

		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent we) {
				// Get the focus when window is opened
				jt.requestFocus();
			}
		});

		setSize(700, 700);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public void UpdateInfoPanel(JTextPane textPane, String text) throws BadLocationException {

		StyledDocument doc = (StyledDocument) textPane.getDocument();
		SimpleAttributeSet keyWord = new SimpleAttributeSet();
		StyleConstants.setForeground(keyWord, Color.BLUE);
		StyleConstants.setBackground(keyWord, Color.YELLOW);
		StyleConstants.setBold(keyWord, true);
		StyleConstants.setLineSpacing(keyWord, 1);

		/*
		 * Style style = doc.addStyle("StyleName", null);
		 * StyleConstants.setIcon(style, new
		 * ImageIcon("src/main/img/dell-logo.png"));
		 * 
		 * doc.insertString(doc.getLength(), "ignored text", style);
		 */
		textPane.selectAll();
		doc.insertString(doc.getLength(), text + "\n", keyWord);
		textPane.setBackground(Color.WHITE);
		textPane.setEditable(false);
		textPane.setMargin(null);
		textPane.setParagraphAttributes(keyWord, false);

		jt.setText("");
		l.setText("");
	}

	public static void main(String args[]) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					new ChatbotPanel();
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}
}