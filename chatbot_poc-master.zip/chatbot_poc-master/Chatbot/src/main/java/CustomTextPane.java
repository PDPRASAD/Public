package main.java;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;

/**
 * A custom text pane that have a background image. To customize the
 * JTextPane we override the paintComponent(Graphics g) method. We have
 * to draw an image before we call the super class paintComponent method.
 */
class CustomTextPane extends JTextPane {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String imageFile;

    /**
     * Constructor of custome text pane.
     * @param imageFile image file name for the text pane background.
     */
    CustomTextPane() {
        super();        
        //
        // To be able to draw the background image the component must
        // not be opaque.
        //
        setOpaque(false);
        setForeground(Color.BLUE);
        
        this.imageFile = imageFile;        
    }

    @Override
    protected void paintComponent(Graphics g) {
        BufferedImage image = null;
        try {
        	/* File currDir = new File(".");
             String path = currDir.getAbsolutePath();
             path = path.substring(0, path.length() - 2);
             System.out.println("HELLO PATH"+path);
             String imgPath = path + File.separator+"main"+File.separator+"img"+ File.separator + "dell-logo.png";
             ImageIcon qmarkIcon = new ImageIcon(getClass().getResource("dell-logo.pn"));
           */  URL url = CustomTextPane.class.getResource("/dell-logo.png");
            image = ImageIO.read(url);
            g.drawImage(image, 0, 0, (int) getSize().getWidth(),
                    (int) getSize().getHeight(), this);
        } catch (IOException e) {
            e.printStackTrace();
        }

        super.paintComponent(g);
    }
}