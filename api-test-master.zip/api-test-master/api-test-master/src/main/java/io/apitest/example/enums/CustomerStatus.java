package io.apitest.example.enums;

/**
 * Created by prasantabiswas on 26/06/18.
 */
public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED,
}
